"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "../../lib/supabaseClient";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setError(error.message);
      setLoading(false);
      return;
    }
    router.push("/dashboard");
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <form onSubmit={handleSubmit} className="max-w-sm w-full">
        <h1 className="text-xl font-semibold mb-6" style={{ color: "var(--text-1)" }}>
          Inicia sesión
        </h1>
        <div className="mb-4">
          <label className="block text-xs font-medium mb-1.5" style={{ color: "var(--text-2)" }}>
            Email
          </label>
          <input
            required
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full py-2.5 px-3 rounded-lg border text-sm outline-none"
            style={{ borderColor: "var(--border)", background: "var(--paper)", color: "var(--text-1)" }}
          />
        </div>
        <div className="mb-4">
          <label className="block text-xs font-medium mb-1.5" style={{ color: "var(--text-2)" }}>
            Contraseña
          </label>
          <input
            required
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full py-2.5 px-3 rounded-lg border text-sm outline-none"
            style={{ borderColor: "var(--border)", background: "var(--paper)", color: "var(--text-1)" }}
          />
        </div>
        {error && (
          <p className="text-sm mb-3" style={{ color: "#B33A3A" }}>
            {error}
          </p>
        )}
        <button
          disabled={loading}
          className="w-full py-3 rounded-lg font-medium text-white text-sm"
          style={{ background: "var(--accent)", opacity: loading ? 0.7 : 1 }}
        >
          {loading ? "Entrando..." : "Entrar"}
        </button>
      </form>
    </main>
  );
}
