import "./globals.css";

export const metadata = {
  title: "Calendario App — gestiona tu barbería o peluquería",
  description: "Cada profesional con su propio panel, sus clientes y sus citas.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
