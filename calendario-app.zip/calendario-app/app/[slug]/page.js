"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { supabase } from "../../lib/supabaseClient";

// Genera huecos de ejemplo cada 30 min entre las 10:00 y las 19:00.
// En producción, esto debería calcularse a partir de las citas ya
// reservadas y del horario de trabajo configurado por el barbero.
function generateSlots() {
  const slots = [];
  for (let h = 10; h < 19; h++) {
    slots.push(`${String(h).padStart(2, "0")}:00`);
    slots.push(`${String(h).padStart(2, "0")}:30`);
  }
  return slots;
}

export default function PublicBookingPage() {
  const { slug } = useParams();
  const [barber, setBarber] = useState(null);
  const [services, setServices] = useState([]);
  const [selectedService, setSelectedService] = useState(null);
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function load() {
      const { data: b } = await supabase.from("barbers").select("*").eq("slug", slug).single();
      setBarber(b);
      if (b) {
        const { data: s } = await supabase
          .from("services")
          .select("*")
          .eq("barber_id", b.id)
          .eq("active", true);
        setServices(s || []);
      }
    }
    load();
  }, [slug]);

  async function handleConfirm() {
    if (!selectedService || !selectedSlot || !name || !phone) return;
    setLoading(true);

    const { data: client } = await supabase
      .from("clients")
      .insert({ barber_id: barber.id, full_name: name, phone })
      .select()
      .single();

    const today = new Date();
    const [h, m] = selectedSlot.split(":").map(Number);
    const startsAt = new Date(today.getFullYear(), today.getMonth(), today.getDate(), h, m);
    const endsAt = new Date(startsAt.getTime() + selectedService.duration_minutes * 60000);

    await supabase.from("appointments").insert({
      barber_id: barber.id,
      client_id: client?.id,
      service_id: selectedService.id,
      starts_at: startsAt.toISOString(),
      ends_at: endsAt.toISOString(),
    });

    setLoading(false);
    setConfirmed(true);
  }

  if (!barber) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <p style={{ color: "var(--text-2)" }}>Cargando...</p>
      </main>
    );
  }

  if (confirmed) {
    return (
      <main className="min-h-screen flex items-center justify-center px-6">
        <div className="max-w-sm text-center">
          <h1 className="text-xl font-semibold mb-2" style={{ color: "var(--text-1)" }}>
            ¡Cita confirmada!
          </h1>
          <p className="text-sm" style={{ color: "var(--text-2)" }}>
            Te esperamos en {barber.business_name} a las {selectedSlot}.
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen px-6 py-10">
      <div className="max-w-md mx-auto">
        <div className="text-center pb-6 mb-6 border-b" style={{ borderColor: "var(--border)" }}>
          <div
            className="w-14 h-14 rounded-2xl mx-auto mb-3 flex items-center justify-center font-semibold text-lg"
            style={{ background: "var(--ink)", color: "var(--paper)" }}
          >
            {barber.business_name.slice(0, 2).toUpperCase()}
          </div>
          <div className="text-lg font-semibold" style={{ color: "var(--text-1)" }}>{barber.business_name}</div>
          <div className="text-xs mt-1" style={{ color: "var(--text-2)" }}>{barber.city}</div>
        </div>

        <div className="text-xs font-semibold uppercase tracking-wide mb-3" style={{ color: "var(--text-3)" }}>
          Elige un servicio
        </div>
        {services.map((s) => (
          <div
            key={s.id}
            onClick={() => setSelectedService(s)}
            className="flex justify-between items-center p-4 rounded-lg border mb-2 cursor-pointer"
            style={{
              borderColor: selectedService?.id === s.id ? "var(--accent)" : "var(--border)",
              background: selectedService?.id === s.id ? "var(--accent-soft)" : "transparent",
            }}
          >
            <div>
              <div className="text-sm font-medium" style={{ color: "var(--text-1)" }}>{s.name}</div>
              <div className="text-xs" style={{ color: "var(--text-3)" }}>{s.duration_minutes} min</div>
            </div>
            <div className="text-sm font-semibold" style={{ color: "var(--text-1)" }}>{s.price} €</div>
          </div>
        ))}

        {selectedService && (
          <>
            <div className="text-xs font-semibold uppercase tracking-wide mt-6 mb-3" style={{ color: "var(--text-3)" }}>
              Elige una hora
            </div>
            <div className="grid grid-cols-3 gap-2 mb-6">
              {generateSlots().map((slot) => (
                <button
                  key={slot}
                  onClick={() => setSelectedSlot(slot)}
                  className="py-2.5 rounded-lg text-sm font-medium border"
                  style={{
                    borderColor: selectedSlot === slot ? "var(--ink)" : "var(--border)",
                    background: selectedSlot === slot ? "var(--ink)" : "transparent",
                    color: selectedSlot === slot ? "var(--paper)" : "var(--text-2)",
                  }}
                >
                  {slot}
                </button>
              ))}
            </div>
          </>
        )}

        {selectedSlot && (
          <div className="mb-6">
            <input
              placeholder="Tu nombre"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full mb-3 py-2.5 px-3 rounded-lg border text-sm outline-none"
              style={{ borderColor: "var(--border)", color: "var(--text-1)" }}
            />
            <input
              placeholder="Tu teléfono"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full py-2.5 px-3 rounded-lg border text-sm outline-none"
              style={{ borderColor: "var(--border)", color: "var(--text-1)" }}
            />
          </div>
        )}

        {selectedService && selectedSlot && (
          <button
            onClick={handleConfirm}
            disabled={loading || !name || !phone}
            className="w-full py-3 rounded-lg font-medium text-white text-sm"
            style={{ background: "var(--accent)", opacity: loading ? 0.7 : 1 }}
          >
            {loading ? "Confirmando..." : "Confirmar cita"}
          </button>
        )}
      </div>
    </main>
  );
}
