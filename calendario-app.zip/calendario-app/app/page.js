import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="max-w-md w-full text-center">
        <h1 className="text-2xl font-semibold mb-3" style={{ color: "var(--text-1)" }}>
          Gestiona tu barbería o peluquería
        </h1>
        <p className="text-sm mb-8" style={{ color: "var(--text-2)" }}>
          Tu agenda, tus servicios y tus clientes, todo en un solo lugar.
        </p>
        <div className="flex flex-col gap-3">
          <Link
            href="/register"
            className="w-full py-3 rounded-lg font-medium text-white text-sm"
            style={{ background: "var(--accent)" }}
          >
            Crear mi cuenta
          </Link>
          <Link
            href="/login"
            className="w-full py-3 rounded-lg font-medium text-sm border"
            style={{ borderColor: "var(--border)", color: "var(--text-1)" }}
          >
            Ya tengo cuenta
          </Link>
        </div>
      </div>
    </main>
  );
}
