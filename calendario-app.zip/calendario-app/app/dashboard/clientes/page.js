"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "../../../lib/supabaseClient";

export default function ClientesPage() {
  const [clients, setClients] = useState([]);

  useEffect(() => {
    async function load() {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase
        .from("clients")
        .select("*")
        .eq("barber_id", user.id)
        .order("full_name", { ascending: true });
      setClients(data || []);
    }
    load();
  }, []);

  return (
    <div>
      <h1 className="text-xl font-semibold mb-1" style={{ color: "var(--text-1)" }}>
        Tus clientes
      </h1>
      <p className="text-sm mb-6" style={{ color: "var(--text-2)" }}>
        Historial y notas de cada cliente
      </p>

      {clients.length === 0 && (
        <p className="text-sm" style={{ color: "var(--text-2)" }}>
          Aún no tienes clientes registrados. Se añaden automáticamente cuando alguien reserva desde tu página pública.
        </p>
      )}

      {clients.map((c) => (
        <Link
          key={c.id}
          href={`/dashboard/clientes/${c.id}`}
          className="flex justify-between items-center py-3 border-b"
          style={{ borderColor: "var(--border)" }}
        >
          <div>
            <div className="text-sm font-medium" style={{ color: "var(--text-1)" }}>{c.full_name}</div>
            <div className="text-xs" style={{ color: "var(--text-3)" }}>{c.phone}</div>
          </div>
        </Link>
      ))}
    </div>
  );
}
