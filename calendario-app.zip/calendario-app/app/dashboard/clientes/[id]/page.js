"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { supabase } from "../../../../lib/supabaseClient";

export default function ClienteDetailPage() {
  const { id } = useParams();
  const [client, setClient] = useState(null);
  const [visits, setVisits] = useState([]);
  const [notes, setNotes] = useState("");

  useEffect(() => {
    async function load() {
      const { data: c } = await supabase.from("clients").select("*").eq("id", id).single();
      setClient(c);
      setNotes(c?.notes || "");

      const { data: v } = await supabase
        .from("appointments")
        .select("id, starts_at, services(name, price)")
        .eq("client_id", id)
        .order("starts_at", { ascending: false });
      setVisits(v || []);
    }
    load();
  }, [id]);

  async function saveNotes() {
    await supabase.from("clients").update({ notes }).eq("id", id);
  }

  if (!client) return null;

  const totalSpent = visits.reduce((sum, v) => sum + (v.services?.price || 0), 0);

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <div
          className="w-14 h-14 rounded-xl flex items-center justify-center font-semibold text-lg flex-shrink-0"
          style={{ background: "var(--accent-soft)", color: "var(--accent-dark)" }}
        >
          {client.full_name.split(" ").map((w) => w[0]).slice(0, 2).join("")}
        </div>
        <div>
          <div className="text-lg font-semibold" style={{ color: "var(--text-1)" }}>{client.full_name}</div>
          <div className="text-sm" style={{ color: "var(--text-2)" }}>{client.phone}</div>
        </div>
      </div>

      <div className="flex rounded-lg border mb-6 overflow-hidden" style={{ borderColor: "var(--border)" }}>
        <Stat label="Visitas totales" value={visits.length} />
        <Stat label="Gasto total" value={`${totalSpent.toFixed(0)} €`} />
      </div>

      <div className="text-xs font-semibold uppercase tracking-wide mb-2" style={{ color: "var(--text-3)" }}>
        Notas
      </div>
      <textarea
        value={notes}
        onChange={(e) => setNotes(e.target.value)}
        onBlur={saveNotes}
        rows={3}
        placeholder="Preferencias, alergias, detalles a recordar..."
        className="w-full p-3 rounded-lg border text-sm outline-none mb-6"
        style={{ borderColor: "var(--border)", color: "var(--text-1)", background: "var(--paper)" }}
      />

      <div className="text-xs font-semibold uppercase tracking-wide mb-2" style={{ color: "var(--text-3)" }}>
        Historial de visitas
      </div>
      {visits.map((v) => (
        <div
          key={v.id}
          className="flex justify-between py-2.5 border-b text-sm"
          style={{ borderColor: "var(--border)" }}
        >
          <div style={{ color: "var(--text-1)" }}>{v.services?.name}</div>
          <div style={{ color: "var(--text-3)" }}>
            {new Date(v.starts_at).toLocaleDateString("es-ES", { day: "numeric", month: "short" })}
          </div>
        </div>
      ))}
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="flex-1 py-4 px-3 text-center border-r last:border-r-0" style={{ borderColor: "var(--border)" }}>
      <div className="text-lg font-semibold" style={{ color: "var(--text-1)" }}>{value}</div>
      <div className="text-[11px] mt-1" style={{ color: "var(--text-3)" }}>{label}</div>
    </div>
  );
}
