"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const NAV = [
  { href: "/dashboard", label: "Agenda" },
  { href: "/dashboard/servicios", label: "Servicios" },
  { href: "/dashboard/clientes", label: "Clientes" },
];

export default function DashboardLayout({ children }) {
  const pathname = usePathname();

  return (
    <div className="min-h-screen px-4 md:px-8 py-8" style={{ background: "var(--paper)" }}>
      <div className="max-w-5xl mx-auto md:flex gap-8 items-start">
        <nav className="flex md:flex-col gap-1 md:w-44 flex-shrink-0 mb-6 md:mb-0 overflow-x-auto">
          {NAV.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className="px-3 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap"
                style={{
                  background: active ? "var(--ink)" : "transparent",
                  color: active ? "var(--paper)" : "var(--text-2)",
                }}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="flex-1 min-w-0">{children}</div>
      </div>
    </div>
  );
}
