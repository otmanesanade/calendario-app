"use client";

import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabaseClient";

export default function DashboardPage() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const startOfDay = new Date();
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date();
      endOfDay.setHours(23, 59, 59, 999);

      const { data } = await supabase
        .from("appointments")
        .select("id, starts_at, status, clients(full_name), services(name, price, duration_minutes)")
        .eq("barber_id", user.id)
        .gte("starts_at", startOfDay.toISOString())
        .lte("starts_at", endOfDay.toISOString())
        .order("starts_at", { ascending: true });

      setAppointments(data || []);
      setLoading(false);
    }
    load();
  }, []);

  const totalIncome = appointments.reduce((sum, a) => sum + (a.services?.price || 0), 0);

  return (
    <div>
      <h1 className="text-xl font-semibold mb-1" style={{ color: "var(--text-1)" }}>
        Hoy
      </h1>
      <p className="text-sm mb-6" style={{ color: "var(--text-2)" }}>
        {new Date().toLocaleDateString("es-ES", { weekday: "long", day: "numeric", month: "long" })}
      </p>

      <div
        className="flex rounded-lg border mb-8 overflow-hidden"
        style={{ borderColor: "var(--border)" }}
      >
        <Stat label="Citas hoy" value={appointments.length} />
        <Stat label="Ingresos hoy" value={`${totalIncome.toFixed(0)} €`} />
      </div>

      <div className="text-xs font-semibold uppercase tracking-wide mb-3" style={{ color: "var(--text-3)" }}>
        Próximas citas
      </div>

      {loading && <p className="text-sm" style={{ color: "var(--text-2)" }}>Cargando...</p>}
      {!loading && appointments.length === 0 && (
        <p className="text-sm" style={{ color: "var(--text-2)" }}>No tienes citas para hoy.</p>
      )}

      {appointments.map((a) => (
        <div
          key={a.id}
          className="flex gap-3 py-3 border-b"
          style={{ borderColor: "var(--border)" }}
        >
          <div className="text-sm font-medium w-14 flex-shrink-0" style={{ color: "var(--text-2)" }}>
            {new Date(a.starts_at).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" })}
          </div>
          <div>
            <div className="text-sm font-medium" style={{ color: "var(--text-1)" }}>
              {a.clients?.full_name || "Cliente"}
            </div>
            <div className="text-xs" style={{ color: "var(--text-2)" }}>
              {a.services?.name} · {a.services?.duration_minutes} min · {a.services?.price} €
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="flex-1 py-4 px-3 text-center border-r last:border-r-0" style={{ borderColor: "var(--border)" }}>
      <div className="text-lg font-semibold" style={{ color: "var(--text-1)" }}>
        {value}
      </div>
      <div className="text-[11px] mt-1" style={{ color: "var(--text-3)" }}>
        {label}
      </div>
    </div>
  );
}
