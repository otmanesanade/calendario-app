"use client";

import { useEffect, useState } from "react";
import { supabase } from "../../../lib/supabaseClient";

export default function ServiciosPage() {
  const [services, setServices] = useState([]);
  const [name, setName] = useState("");
  const [duration, setDuration] = useState(30);
  const [price, setPrice] = useState("");
  const [showForm, setShowForm] = useState(false);

  async function load() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;
    const { data } = await supabase
      .from("services")
      .select("*")
      .eq("barber_id", user.id)
      .order("created_at", { ascending: true });
    setServices(data || []);
  }

  useEffect(() => {
    load();
  }, []);

  async function handleAdd(e) {
    e.preventDefault();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;
    await supabase.from("services").insert({
      barber_id: user.id,
      name,
      duration_minutes: Number(duration),
      price: Number(price),
    });
    setName("");
    setDuration(30);
    setPrice("");
    setShowForm(false);
    load();
  }

  return (
    <div>
      <h1 className="text-xl font-semibold mb-1" style={{ color: "var(--text-1)" }}>
        Tus servicios
      </h1>
      <p className="text-sm mb-6" style={{ color: "var(--text-2)" }}>
        Precio, duración y visibilidad
      </p>

      {services.map((s) => (
        <div
          key={s.id}
          className="flex justify-between items-center py-3 border-b"
          style={{ borderColor: "var(--border)" }}
        >
          <div>
            <div className="text-sm font-medium" style={{ color: "var(--text-1)" }}>{s.name}</div>
            <div className="text-xs" style={{ color: "var(--text-3)" }}>{s.duration_minutes} min</div>
          </div>
          <div className="text-sm font-semibold" style={{ color: "var(--text-1)" }}>{s.price} €</div>
        </div>
      ))}

      {!showForm ? (
        <button
          onClick={() => setShowForm(true)}
          className="mt-4 text-sm font-medium"
          style={{ color: "var(--accent-dark)" }}
        >
          + Añadir servicio
        </button>
      ) : (
        <form onSubmit={handleAdd} className="mt-5 max-w-sm">
          <input
            required
            placeholder="Nombre del servicio"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full mb-3 py-2.5 px-3 rounded-lg border text-sm outline-none"
            style={{ borderColor: "var(--border)", color: "var(--text-1)" }}
          />
          <div className="flex gap-3 mb-3">
            <input
              required
              type="number"
              placeholder="Minutos"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              className="w-full py-2.5 px-3 rounded-lg border text-sm outline-none"
              style={{ borderColor: "var(--border)", color: "var(--text-1)" }}
            />
            <input
              required
              type="number"
              placeholder="Precio €"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="w-full py-2.5 px-3 rounded-lg border text-sm outline-none"
              style={{ borderColor: "var(--border)", color: "var(--text-1)" }}
            />
          </div>
          <button
            className="py-2.5 px-5 rounded-lg text-sm font-medium text-white"
            style={{ background: "var(--accent)" }}
          >
            Guardar
          </button>
        </form>
      )}
    </div>
  );
}
