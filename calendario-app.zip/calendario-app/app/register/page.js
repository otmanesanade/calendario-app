"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "../../lib/supabaseClient";

function slugify(text) {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export default function RegisterPage() {
  const router = useRouter();
  const [businessName, setBusinessName] = useState("");
  const [businessType, setBusinessType] = useState("barberia");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError("");

    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
    });

    if (authError) {
      setError(authError.message);
      setLoading(false);
      return;
    }

    const userId = authData.user?.id;
    if (!userId) {
      setError("Revisa tu email para confirmar la cuenta antes de continuar.");
      setLoading(false);
      return;
    }

    const slug = slugify(businessName) + "-" + userId.slice(0, 4);

    const { error: insertError } = await supabase.from("barbers").insert({
      id: userId,
      business_name: businessName,
      slug,
      business_type: businessType,
      phone,
      city,
    });

    if (insertError) {
      setError(insertError.message);
      setLoading(false);
      return;
    }

    router.push("/dashboard");
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-12">
      <form
        onSubmit={handleSubmit}
        className="max-w-sm w-full"
      >
        <h1 className="text-xl font-semibold mb-1" style={{ color: "var(--text-1)" }}>
          Crea tu espacio
        </h1>
        <p className="text-sm mb-6" style={{ color: "var(--text-2)" }}>
          Configura tu perfil en dos minutos
        </p>

        <Field label="Nombre del negocio">
          <input
            required
            value={businessName}
            onChange={(e) => setBusinessName(e.target.value)}
            placeholder="Estudio Marco"
          />
        </Field>

        <Field label="Tipo">
          <div className="flex gap-2">
            {[
              ["barberia", "Barbería"],
              ["peluqueria", "Peluquería"],
              ["ambos", "Ambos"],
            ].map(([value, label]) => (
              <button
                type="button"
                key={value}
                onClick={() => setBusinessType(value)}
                className="flex-1 py-2 rounded-lg text-sm font-medium border"
                style={{
                  borderColor: businessType === value ? "var(--accent)" : "var(--border)",
                  color: businessType === value ? "var(--accent-dark)" : "var(--text-2)",
                  background: businessType === value ? "var(--accent-soft)" : "transparent",
                }}
              >
                {label}
              </button>
            ))}
          </div>
        </Field>

        <Field label="Teléfono">
          <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+34 611 22 33 44" />
        </Field>

        <Field label="Ciudad">
          <input value={city} onChange={(e) => setCity(e.target.value)} placeholder="Madrid" />
        </Field>

        <Field label="Email">
          <input
            required
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="tu@email.com"
          />
        </Field>

        <Field label="Contraseña">
          <input
            required
            type="password"
            minLength={6}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Field>

        {error && (
          <p className="text-sm mb-3" style={{ color: "#B33A3A" }}>
            {error}
          </p>
        )}

        <button
          disabled={loading}
          className="w-full py-3 rounded-lg font-medium text-white text-sm mt-1"
          style={{ background: "var(--accent)", opacity: loading ? 0.7 : 1 }}
        >
          {loading ? "Creando..." : "Continuar"}
        </button>
      </form>
    </main>
  );
}

function Field({ label, children }) {
  return (
    <div className="mb-4">
      <label className="block text-xs font-medium mb-1.5" style={{ color: "var(--text-2)" }}>
        {label}
      </label>
      <StyledInputWrapper>{children}</StyledInputWrapper>
    </div>
  );
}

function StyledInputWrapper({ children }) {
  return (
    <div
      className="[&_input]:w-full [&_input]:py-2.5 [&_input]:px-3 [&_input]:rounded-lg [&_input]:border [&_input]:text-sm [&_input]:outline-none"
      style={{ "--tw-border-opacity": 1 }}
    >
      {children}
      <style jsx>{`
        div :global(input) {
          border-color: var(--border);
          background: var(--paper);
          color: var(--text-1);
        }
        div :global(input:focus) {
          border-color: var(--accent);
          box-shadow: 0 0 0 3px var(--accent-soft);
        }
      `}</style>
    </div>
  );
}
